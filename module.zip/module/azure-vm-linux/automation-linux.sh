!#/bin/bash

set -e
cd /tmp
sudo wget https://aka.ms/downloadazcopy-v10-linux 
tar -xvf downloadazcopy-v10-linux
sudo cp azcopy_linux_amd64_*/azcopy /usr/bin/
sudo azcopy login --identity
CustomerId=9c0e25de-0221-5af6-e040-10ac13043f6a
ActivationId=e75ab57c-f0bb-486f-a63b-6d408864fe54
sed -i 's/AllowUsers.*/& appadmin/g' /etc/ssh/sshd_config
service sshd restart
#/usr/local/qualys/cloud-agent/bin/qualys-cloud-agent.sh ActivationId=$ActivationId  CustomerId=$CustomerId
#systemctl enable qualys-cloud-agent
#systemctl restart qualys-cloud-agent
export hostname=`curl -H Metadata:true "http://169.254.169.254/metadata/instance/compute/name?api-version=2019-08-01&format=text"`
export location=`curl -H Metadata:true "http://169.254.169.254/metadata/instance/compute/location?api-version=2019-08-01&format=text"`
export vmId=`curl -H Metadata:true "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2019-08-01&format=text"`
export subscriptionId=`curl -H Metadata:true "http://169.254.169.254/metadata/instance/compute/subscriptionId?api-version=2019-08-01&format=text"`
export id=`curl -H Metadata:true "http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/privateIpAddress?api-version=2017-08-01&format=text"`
export vnetname=`grep -oPm1 "(?<=<ns1:CustomData>)[^<]+" </var/lib/waagent/ovf-env.xml | base64 --decode` 
rm -rf /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
mkdir -p /opt/splunkforwarder/etc/apps/deployment_client/default
echo [deployment-client] > /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
echo clientName = $location:$vnetname:$subscriptionId >> /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
echo "disabled = false" >> /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
echo "[target-broker:deploymentServer]" >> /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
echo "targetUri = ds-useast.gelogging.com:443" >> /opt/splunkforwarder/etc/apps/deployment_client/default/deploymentclient.conf
rm -rf /opt/splunkforwarder/etc/system/local/inputs.conf
mkdir -p /opt/splunkforwarder/etc/system/local
echo host = $hostname:$id:$location:$vnetname:$subscriptionId > /opt/splunkforwarder/etc/system/local/inputs.conf
mkdir -p /opt/splunkforwarder/etc/apps/deployment/local
echo "[deployment]" >> /opt/splunkforwarder/etc/apps/deployment/local/server.conf
echo "pass4SymmKey = D85A9TuK8itcU^HA#04Wi7quVL4F#4 " >> /opt/splunkforwarder/etc/apps/deployment/local/server.conf
chown root:root /opt/splunkforwarder/etc/system/local/inputs.conf
chmod 600 /opt/splunkforwarder/etc/system/local/inputs.conf
/opt/splunkforwarder/bin/splunk enable boot-start
/opt/splunkforwarder/bin/splunk stop
/opt/splunkforwarder/bin/splunk start --answer-yes --no-prompt --accept-license
yum update -y
yum install unzip -y
systemctl stop falcon-sensor
/opt/CrowdStrike/falconctl -d -f --aid
systemctl start falcon-sensor
chage -I -1 -m 0 -M 99999 -E -1 gecloud

