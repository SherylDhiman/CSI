mkdir 'C:\\Program Files\\SplunkUniversalForwarder\\etc\\apps\\deployment_client'
mkdir 'C:\\Program Files\\SplunkUniversalForwarder\\etc\\apps\\deployment_client\\default'
remove-item -path 'C:\\Program Files\\SplunkUniversalForwarder\\etc\\system\\local\\server.conf'
remove-item -path 'C:\\Program Files\\SplunkUniversalForwarder\\etc\\auth\\server.pem'
Set-Variable -Name \"hostname\" -Value (Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/compute/name?api-version=2017-08-01&format=text")
Set-Variable -Name \"ip\" -Value (Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/privateIpAddress?api-version=2017-08-01&format=text")
Set-Variable -Name \"location\" -Value (Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/compute/location?api-version=2017-08-01&format=text")
Set-Variable -Name \"vmId\" -Value (Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2017-08-01&format=text")
Set-Variable -Name \"subscriptionId\" -Value (Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/compute/subscriptionId?api-version=2017-08-01&format=text")
$vnet = Get-Content -Path C:\AzureData\Customdata.bin
$vnetname = $vnet.Split("/")[0]
Set-Variable -Name \"input\" -Value  "host = ${\hostname\}:${\ip\}:${\location\}:${vnetname}:${\subscriptionId\}"
Set-Variable -Name \"deploymentclient\" -Value  "clientName = ${\location\}:${vnetname}:${\subscriptionId\}"
echo $input
echo $deploymentclient
echo $ip
echo $hostname
echo $location
echo $vmId
echo $vnetname
echo $subscriptionId
cd 'C:\\Program Files\\SplunkUniversalForwarder\\etc\\system\\local'
Set-Content -Path  '.\\inputs.conf' -Value "${\input\}"
Set-Content -Path '.\\server.conf' -Value \"[deployment] `r`npass4SymmKey = D85A9TuK8itcU^HA#04Wi7quVL4F#4\"
Set-Content -Path  '.\\deploymentclient.conf' -Value "${\deploymentclient\}"
restart-service -name SplunkForwarder
